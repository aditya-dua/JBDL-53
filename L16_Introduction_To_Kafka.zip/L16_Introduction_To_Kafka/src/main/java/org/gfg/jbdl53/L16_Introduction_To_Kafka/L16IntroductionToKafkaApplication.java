package org.gfg.jbdl53.L16_Introduction_To_Kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L16IntroductionToKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(L16IntroductionToKafkaApplication.class, args);
	}

}
