package org.gfg.jbdl53.L16_Introduction_To_Kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L16IntroductionToKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
