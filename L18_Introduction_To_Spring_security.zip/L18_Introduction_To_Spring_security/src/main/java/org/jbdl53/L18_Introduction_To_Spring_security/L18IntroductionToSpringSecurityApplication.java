package org.jbdl53.L18_Introduction_To_Spring_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L18IntroductionToSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(L18IntroductionToSpringSecurityApplication.class, args);
	}

}
