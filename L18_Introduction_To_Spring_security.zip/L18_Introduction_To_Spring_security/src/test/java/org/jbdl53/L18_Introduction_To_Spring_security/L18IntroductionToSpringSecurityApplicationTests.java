package org.jbdl53.L18_Introduction_To_Spring_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L18IntroductionToSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
