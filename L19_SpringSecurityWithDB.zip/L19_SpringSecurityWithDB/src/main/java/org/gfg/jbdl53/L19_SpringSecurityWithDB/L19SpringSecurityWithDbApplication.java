package org.gfg.jbdl53.L19_SpringSecurityWithDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L19SpringSecurityWithDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(L19SpringSecurityWithDbApplication.class, args);
	}

}
