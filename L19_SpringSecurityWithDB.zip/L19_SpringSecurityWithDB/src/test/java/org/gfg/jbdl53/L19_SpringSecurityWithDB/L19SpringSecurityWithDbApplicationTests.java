package org.gfg.jbdl53.L19_SpringSecurityWithDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L19SpringSecurityWithDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
