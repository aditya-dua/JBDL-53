package org.gfg.jbdl53.l18_SpringBootFile_ResponseEntity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L18SpringBootFileResponseEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
