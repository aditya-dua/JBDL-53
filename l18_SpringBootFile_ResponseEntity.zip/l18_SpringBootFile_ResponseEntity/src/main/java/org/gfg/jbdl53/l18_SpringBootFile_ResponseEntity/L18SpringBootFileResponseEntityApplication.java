package org.gfg.jbdl53.l18_SpringBootFile_ResponseEntity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L18SpringBootFileResponseEntityApplication {

	public static void main(String[] args) {
		SpringApplication.run(L18SpringBootFileResponseEntityApplication.class, args);
	}

}
