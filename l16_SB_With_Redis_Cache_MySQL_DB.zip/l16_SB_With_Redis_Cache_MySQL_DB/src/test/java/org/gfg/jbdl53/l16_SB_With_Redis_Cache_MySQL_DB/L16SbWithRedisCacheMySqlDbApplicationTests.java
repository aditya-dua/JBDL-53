package org.gfg.jbdl53.l16_SB_With_Redis_Cache_MySQL_DB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L16SbWithRedisCacheMySqlDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
