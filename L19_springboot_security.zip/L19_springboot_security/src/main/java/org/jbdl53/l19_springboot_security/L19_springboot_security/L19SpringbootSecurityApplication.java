package org.jbdl53.l19_springboot_security.L19_springboot_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L19SpringbootSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(L19SpringbootSecurityApplication.class, args);
	}

}
