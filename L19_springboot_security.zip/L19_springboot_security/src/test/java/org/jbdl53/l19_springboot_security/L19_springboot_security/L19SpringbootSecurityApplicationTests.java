package org.jbdl53.l19_springboot_security.L19_springboot_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L19SpringbootSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
